 
  <!-- ***************Footer******** -->

  <!--Footer-->


<div class="container-fluid Kaarwaa_footer" style="" >
  
  <div class="row" >
    <div class="col-sm-4"  >
        
        <a href="/faq.php"><h6>FAQ<h6></a>
        <a href="/privacy_policy/privacy_policy.php"><h6>Privacy Poilcy</h6></a>
        <a href="/certificate_verification/certificate_verification.php"><h6>Certificate Verification</h6></a>
        <a href="/feedback/feedback.php"><h6>Feedback to developers</h6></a>
        <a href="/developers/developers.php"><h6>Developers</h6></a>
        
    </div>
    <div class="col-sm-4 footer_div_hide " >
      <h6>Contact Us</h6>
      <p>Jabalpur Engineering College,<br>
       Gokalpur, Jabalpur (M.P.)<br>
      +917617319811<br>
      kaarwaa.n16@gmail.com</p>
    </div>
    <div class="col-sm-4 footer_div_hide" >
        <a href="/child_education/child_education.php"><h6>Child Education</h6></a>
        <a href="/orphanage/orphanage.php"><h6>Oraphaneg Visit<h6></a>
        <a href="/plantation/plantation.php"><h6>Plantation</h6></a>
        <a href="/cloth_distibution/cloth_distibution.php"><h6>Cloth Distribution<h6></a>  
        
        
    </div>
  </div>  
</div>
<div class="container-fluid bottom_line">
    <p>© 2019 JEC KAARWAA.N... All Rights Reserved.</p>
</div>




<style type="text/css">



.Kaarwaa_footer
{
  background-color:gray;
  background-color: #444342;
  padding-top: 20px;
  text-align: center;
  color:#BFBCBC;
}
.Kaarwaa_footer a
{
  color:#BFBCBC;
}
.Kaarwaa_footer p
{
  color:#BFBCBC;
}
.Kaarwaa_footer h6
{
  color:#BFBCBC;
}  

.bottom_line
{
  background-color: #444342;text-align: center;border-top: 1px solid lightgray;
  color: #BFBCBC;
}
  
 /*media query if screen size less than 576*/
  @media only screen and (max-width: 575px) { 
  .footer_div_hide
   {
    display: none;
   }  

  }
  
  /*media query if screen size less than 768*/
  @media only screen and (max-width: 768px) {
  
  
 

 
}

  /*media query if screen size greater than 768*/
  @media only screen  and (min-width : 768px) 
{
    

    
}

 


</style>